<?php

require_once dirname(__FILE__).'/../../../core/php/core.inc.php';

function dobiss_install() {
    $cron = cron::byClassAndFunction('dobiss', 'daemon');
    if (!is_object($cron)) {
        $cron = new cron();
        $cron->setClass('dobiss');
        $cron->setFunction('daemon');
        $cron->setEnable(1);
        $cron->setDeamon(1);
        $cron->setSchedule('* * * * *');
        $cron->setTimeout('1440');
        $cron->save();
    }
}

function dobiss_update() {
  $cron = cron::byClassAndFunction('dobiss', 'pull');
  if (is_object($cron)) {
      $cron->remove();
  }
    $cron = cron::byClassAndFunction('dobiss', 'daemon');
    if (!is_object($cron)) {
        $cron = new cron();
        $cron->setClass('dobiss');
        $cron->setFunction('daemon');
        $cron->setEnable(1);
        $cron->setDeamon(1);
        $cron->setSchedule('* * * * *');
        $cron->setTimeout('1440');
        $cron->save();
    }
    $cron->stop();
}

function dobiss_remove() {
    $cron = cron::byClassAndFunction('dobiss', 'pull');
    if (is_object($cron)) {
        $cron->remove();
    }
    $cron = cron::byClassAndFunction('dobiss', 'daemon');
    if (is_object($cron)) {
        $cron->stop();
        $cron->remove();
    }
}