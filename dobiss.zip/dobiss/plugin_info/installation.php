<?php

require_once dirname(__FILE__).'/../../../core/php/core.inc.php';

function dobiss_install() {

}

function dobiss_update() {

}

function dobiss_remove() {

}

